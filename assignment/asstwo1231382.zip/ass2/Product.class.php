<?php
class Product {
    private $productId;
    private $productName;
    private $category;
    private $description;
    private $price;
    private $quantity;
    private $rating;
    private $photo1;
    private $photo2;
    private $photo3;
    private $defaultPhoto;

    public function __construct($prodId, $prodName, $cate, $desc, $price, $quan, $rate, $p1, $p2, $p3, $dP) {
        $this->productId = $prodId;
        $this->productName = $prodName;
        $this->category = $cate;
        $this->description = $desc;
        $this->price = $price;
        $this->quantity = $quan;
        $this->rating = $rate;
        $this->photo1 = $p1;
        $this->photo2 = $p2;
        $this->photo3 = $p3;
        $this->defaultPhoto = $dP;
    }

    public function getProductId() { return $this->productId; }
    public function getProductName() { return $this->productName; }
    public function getCategory() { return $this->category; }
    public function getDescription() { return $this->description; }
    public function getPrice() { return $this->price; }
    public function getQuantity() { return $this->quantity; }
    public function getRating() { return $this->rating; }
    public function getPhoto1() { return $this->photo1; }
    public function getPhoto2() { return $this->photo2; }
    public function getPhoto3() { return $this->photo3; }
    public function getDefaultPhoto() { return $this->defaultPhoto; }

    public function setProductId($prodId) { $this->productId = $prodId; }
    public function setProductName($prodName) { $this->productName = $prodName; }
    public function setCategory($cate) { $this->category = $cate; }
    public function setDescription($desc) { $this->description = $desc; }
    public function setPrice($price) { $this->price = $price; }
    public function setQuantity($quan) { $this->quantity = $quan; }
    public function setRating($rate) { $this->rating = $rate; }
    public function setPhoto1($p1) { $this->photo1 = $p1; }
    public function setPhoto2($p2) { $this->photo2 = $p2; }
    public function setPhoto3($p3) { $this->photo3 = $p3; }
    public function setDefaultPhoto($p) { $this->defaultPhoto = $p; }

    public function displayInTable($uRole = 'guest') {
        $defaultPhoto = $this->defaultPhoto;
        $photoFilename = $this->$defaultPhoto;

        $photovisual = "<img src='images/$photoFilename' width='60' height='60' />";

        $actions = "";
        if ($uRole == 'employee') {
            $actions = "<a href='view.php?id={$this->productId}'>View</a> | <a href='edit.php?id={$this->productId}'>Edit</a>";
        } elseif ($uRole == 'customer') {
            $actions = "<a href='view.php?id={$this->productId}'>View</a> | <a href='add_to_basket.php?id={$this->productId}'>Add to Basket</a>";
        } else {
            $actions = "<a href='view.php?id={$this->productId}'>View</a>";
        }

        return "<tr>
                    <td>{$photovisual}</td>
                    <td><a href='view.php?id={$this->productId}'>{$this->productId}</a></td>
                    <td>" . $this->productName. "</td>
                    <td>" . $this->category . "</td>
                    <td>{$this->price}</td>
                    <td>{$this->quantity}</td>
                    <td>{$actions}</td>
                </tr>";
    }


    public function displayProductPage($uRole = 'guest') {
        $defaultPhotoField = $this->defaultPhoto;
        $photoFilename = $this->$defaultPhotoField;

        $photovisual = "<img src='images/$photoFilename' width='200' />";

        $isEmployee = ($uRole == 'employee');
        $disabled = $isEmployee ? '' : 'disabled';
        $readonly = $isEmployee ? '' : 'readonly';

        $photo1Checked = ($this->defaultPhoto == 'photo1') ? 'checked' : '';
        $photo2Checked = ($this->defaultPhoto == 'photo2') ? 'checked' : '';
        $photo3Checked = ($this->defaultPhoto == 'photo3') ? 'checked' : '';

        $html = "<main>
            <h2>Product Details</h2>
            <form method='post' action='edit.php'>
                <input type='hidden' name='product_id' value='{$this->productId}'>
                
                <fieldset>
                    <legend>Product Information</legend>
                    
                    <label>Product ID:</label>
                    <input type='text' value='{$this->productId}' disabled><br><br>
                    
                    <label>Product Name:</label>
                    <input type='text' value='" . ($this->productName) . "' disabled><br><br>
                    
                    <label>Category:</label>
                    <input type='text' value='" . ($this->category) . "' disabled><br><br>
                    
                    <label>Description:</label>
                    <textarea name='description' rows='5' cols='42' $readonly>" . ($this->description) . "</textarea><br><br>
                    
                    <label>Price (\$):</label>
                    <input type='number' name='price' step='0.01' value='{$this->price}' $readonly><br><br>
                    
                    <label>Quantity:</label>
                    <input type='number' name='quantity' value='{$this->quantity}' $readonly><br><br>
                    
                    <label>Rating:</label>
                    <input type='text' value='{$this->rating}' disabled><br><br>";

        if ($isEmployee) {
            $html .= "
                    <label>Default Photo:</label><br>
                    <input type='radio' name='default_photo' value='photo1' $photo1Checked> Photo 1
                    <input type='radio' name='default_photo' value='photo2' $photo2Checked> Photo 2
                    <input type='radio' name='default_photo' value='photo3' $photo3Checked> Photo 3
                    <br><br>";
        } else {
            $html .= "
                    <label>Default Photo:</label><br>
                    <input type='radio' name='default_photo' value='photo1' $photo1Checked disabled> Photo 1
                    <input type='radio' name='default_photo' value='photo2' $photo2Checked disabled> Photo 2
                    <input type='radio' name='default_photo' value='photo3' $photo3Checked disabled> Photo 3
                    <br><br>";
        }

        $html .= "
                    <div>
                        <label>All Photos:</label><br>
                        <img src='images/{$this->photo1}' width='100'>
                        <img src='images/{$this->photo2}' width='100'>
                        <img src='images/{$this->photo3}' width='100'>
                    </div>
                    <br>
                    $photovisual
                    <br><br>";

        if ($isEmployee) {
            $html .= "<button type='submit'>Save Changes</button>";
        }

        $html .= "
                    <a href='products.php'>Back to Products</a>
                </fieldset>
            </form>";

        if ($uRole == 'customer') {
            $html .= "
            <form method='get' action='add_to_basket.php'>
                <input type='hidden' name='id' value='{$this->productId}'>
                <button type='submit'>Add to Basket</button>
            </form>";
        }

        $html .= "</main>";

        return $html;
    }

}
?>