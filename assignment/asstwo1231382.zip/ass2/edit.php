<?php
session_start();


if($_SESSION['role']!='employee'){
    header('location:index.html');
exit();
}
$pdo = require('dbconfig.inc.php');
if($_SERVER['REQUEST_METHOD'] === 'GET'){
    $product_id = $_GET['id'] ?? 0;
} else {
    $product_id = $_POST['product_id'] ?? 0;
}
if($product_id <= 0){
    header("Location: products.php");
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM products WHERE product_id = :id");
$stmt->execute([':id' => $product_id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$product){
    include 'header.inc.php';
    echo "<h2>Error</h2><p>Product not found.</p>";
    echo "<p><a href='products.php'>Back to Products</a></p>";
    include 'footer.inc.php';
    exit();
}

$errors = [];
$success = false;
if($_SERVER['REQUEST_METHOD']==='POST'){
    $name=$_POST['name'];
    $description=$_POST['description'];
    $price=$_POST['price'];
    $category=$_POST['category'];
    $Quantity=$_POST['quantity'];
    $rating=$_POST['rating'];
    $default_photo = $_POST['default_photo'];
    $image1=$_FILES['image1']['name'];
    $image2=$_FILES['image2']['name'];
    $image3=$_FILES['image3']['name'];
    if($price <= 0){
        $errors[] = "Price must be a positive value.";
    }
    if($Quantity < 0){
        $errors[] = "Quantity must be a non-negative integer.";
    }
    if(empty($description)){
        $errors[] = "Description cannot be empty.";
    }
if(empty($errors)) {

    $Sql = "UPDATE products SET description = :description, price = :price, quantity = :quantity, default_photo = :default_photo WHERE product_id = :id";
    $stmt = $pdo->prepare($Sql);
    $stmt->execute([
        ":description" => $description,
        ":price" => $price,
        ":quantity" => $Quantity,
        ":default_photo" => $default_photo,
        ":id" => $product_id
    ]);
    if(!empty($_FILES['image1']['name'])){
        $image1 = $_FILES['image1']['name'];
        move_uploaded_file($_FILES['image1']['tmp_name'], "images/" . $image1);
        $stmt = $pdo->prepare("UPDATE products SET photo1 = :photo WHERE product_id = :id");
        $stmt->execute([":photo" => $image1, ":id" => $product_id]);
    }

    if(!empty($_FILES['image2']['name'])){
        $image2 = $_FILES['image2']['name'];
        move_uploaded_file($_FILES['image2']['tmp_name'], "images/" . $image2);
        $stmt = $pdo->prepare("UPDATE products SET photo2 = :photo WHERE product_id = :id");
        $stmt->execute([":photo" => $image2, ":id" => $product_id]);
    }

    if(!empty($_FILES['image3']['name'])){
        $image3 = $_FILES['image3']['name'];
        move_uploaded_file($_FILES['image3']['tmp_name'], "images/" . $image3);
        $stmt = $pdo->prepare("UPDATE products SET photo3 = :photo WHERE product_id = :id");
        $stmt->execute([":photo" => $image3, ":id" => $product_id]);
    }

}
}
?>


?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>
    edit the products
</title>
</head>
<body>
<?php
include 'header.inc.php';
?>
<form method="post" action="edit.php" enctype="multipart/form-data">
    <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">

    <fieldset>
        <legend>Edit Product</legend>



        <label>Product ID:</label>
        <input type="text" value="<?php echo $product['product_id']; ?>" disabled>
        <br><br>

        <label>Product Name:</label>
        <input type="text" value="<?php echo $product['product_name']; ?>" disabled>
        <br><br>

        <label>Category:</label>
        <input type="text" value="<?php echo $product['category']; ?>" disabled>
        <br><br>

        <label>Rating (1-5):</label>
        <input type="text" value="<?php echo $product['rating']; ?>" disabled>
        <br><br>

        <label>Description:</label>
        <textarea name="description" rows="5" cols="40" required><?php echo $product['description']; ?></textarea>
        <br><br>

        <label>Price (USD):</label>
        <input type="number" name="price" step="0.01" value="<?php echo $product['price']; ?>" required>
        <br><br>

        <label>Quantity in Stock:</label>
        <input type="number" name="quantity" value="<?php echo $product['quantity']; ?>" required>
        <br><br>

        <label>Default Photo:</label><br>
        <input type="radio" name="default_photo" value="photo1" <?php echo ($product['default_photo'] == 'photo1') ? 'checked' : ''; ?>> Photo 1
        <input type="radio" name="default_photo" value="photo2" <?php echo ($product['default_photo'] == 'photo2') ? 'checked' : ''; ?>> Photo 2
        <input type="radio" name="default_photo" value="photo3" <?php echo ($product['default_photo'] == 'photo3') ? 'checked' : ''; ?>> Photo 3
        <br><br>


        <label>Current Photos:</label><br>
        <img src="images/<?php echo $product['photo1']; ?>" width="100" alt="Photo 1">
        <img src="images/<?php echo $product['photo2']; ?>" width="100" alt="Photo 2">
        <img src="images/<?php echo $product['photo3']; ?>" width="100" alt="Photo 3">
        <br><br>


        <label>Replace Photo 1 :</label>
        <input type="file" name="image1" accept="image/jpeg">
        <br><br>

        <label>Replace Photo 2 :</label>
        <input type="file" name="image2" accept="image/jpeg">
        <br><br>

        <label>Replace Photo 3 :</label>
        <input type="file" name="image3" accept="image/jpeg">
        <br><br>

        <button type="submit">Save Changes</button>
        <a href="products.php">Cancel</a>

    </fieldset>
</form>
<?php
include 'footer.inc.php';
?>
</body>

</html>