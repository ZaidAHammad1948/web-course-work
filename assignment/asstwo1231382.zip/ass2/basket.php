<?php
session_start();
$pdo=require_once "dbconfig.inc.php";
if($_SESSION['loggedIn'] == false){
    header("location: index.php");
exit();
}
if($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["remove"])){
    $removedItem = $_GET["remove"];
    if(isset($_SESSION["basket"][$removedItem])){
        unset($_SESSION["basket"][$removedItem]);
    }
    header("location: basket.php");
    exit();
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
    foreach($_POST["quantity"] as $id => $qty){
        if($qty>0){
            $_SESSION["basket"][$id]['quantity'] = $qty;
        }else{
            unset($_SESSION["basket"][$id]);
        }
    }
    header("Location: basket.php");
    exit();
}

$basket = isset($_SESSION['basket']) ? $_SESSION['basket'] : [];
$total = 0;
$has_items = !empty($basket);
?>
<!DOCTYPE html>
<html lang = "en">
<head>
    <title>
        basket
    </title>
</head>
<body>
<?php
include 'header.inc.php';
?>

<form method="POST" action="basket.php">
    <table>
        <thead>
        <tr>
            <th>
                Image
            </th>
            <th>
                product id
            </th>
            <th>
                unit price
            </th>
            <th>
                quantity
            </th>
            <th>
                total price
            </th>
            <th>
                action
            </th>
        </tr>
        </thead>
        <tbody>
        <?php
        foreach($basket as $id => $item){
            $tot = $item['unit_price'] * $item['quantity'];
            $total = $total + $tot;

        ?>
        <tr>
            <td>
                <img src="images/<?php echo $item['photo']; ?>" width="60">
            </td>
            <td>
                <?php echo "$".$item['unit_price']; ?>
            </td>
            <td>
                <input type="number" name="quantity[<?php echo $id; ?>]" value="<?php echo $item['quantity']; ?>" min="1">
            </td>
            <td>
                <?php echo "$".$tot; ?>
            </td>
            <a href="basket.php?remove=<?php echo $id; ?>">Remove</a>
        </tr>
        <?php
        }
        ?>
        </tbody>
        <tfoot>
        <tr>
            <td>
                total:
            </td>
            <td>
                <?php echo "$".$total; ?>
            </td>
        </tr>
        </tfoot>
    </table>
    <br>
    <input type="submit" name="update" value="Update Quantities">
    <h4>
        <a href="products.php">Continue Shopping</a> <br><br>
        <a href="checkout.php">Proceed to Checkout</a>
    </h4>
</form>
<?php
include 'footer.inc.php';
?>
</body>
</html>
