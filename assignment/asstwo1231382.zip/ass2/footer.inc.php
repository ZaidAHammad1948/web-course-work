<!Doctype html >
<html>

<body>
<hr>
<footer>
    <address>
        PalStar Store<br>
        Nablus, Palestine<br>
        Phone: +970568270179<br>
        Email: palstar.store@gmail.com
    </address>
    <p><a href="contactus.php">Contact Us</a></p>
    <p>Last updated: <?PHP echo date("Y-m-d");
    ?></p>
</footer>
</body>
</html>