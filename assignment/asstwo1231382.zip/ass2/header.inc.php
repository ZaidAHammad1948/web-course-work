<?php
session_start();
if($_SESSION['loggedIn'] == true){;
    $role=$_SESSION['role'];
    echo "Name:".$_SESSION['Name']."<br>";
    echo "Role:".$role;
}else{
    echo "Guest";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>
        PalStar
    </title>
</head>
<body>
<header>
    <h1>
        PalStar Online-store
    </h1>
    <nav>
        <a href="products.php">
            Products
        </a>

        <?php
        if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true) {
            echo "<a href='logout.php'>Logout</a>";
            echo "         <a href='basket.php'>Basket</a>";
        }
        else if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == false) {
            echo "<a href='login.php'>Login</a>";
            echo "<a href='register.php'>Register</a>";
        }
        ?>


    </nav>
</header>
</body>
</html>
