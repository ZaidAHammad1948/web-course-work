<?php
session_start();
if($_SESSION['loggedIn'] == false || $_SESSION['role'] != "employee"){
    header("Location: login.php");
    exit();
}
$pdo=require('dbconfig.inc.php');
if($_SERVER['REQUEST_METHOD']==='POST'){
    $name=$_POST['name'];
    $description=$_POST['description'];
    $price=$_POST['price'];
    $category=$_POST['category'];
    $Quantity=$_POST['quantity'];
    $rating=$_POST['rating'];
    $image1=$_FILES['image1']['name'];
    $image2=$_FILES['image2']['name'];
    $image3=$_FILES['image3']['name'];

    move_uploaded_file($_FILES['image1']['tmp_name'], "images/" . $image1);
    move_uploaded_file($_FILES['image2']['tmp_name'], "images/" . $image2);
    move_uploaded_file($_FILES['image3']['tmp_name'], "images/" . $image3);

    $Sql="INSERT INTO products (product_name, description, price,quantity,rating, category, photo1, photo2, photo3) VALUES (:name, :description, :price,:quantity,:rating, :category, :image1, :image2, :image3)";
    $stmt=$pdo->prepare($Sql);
    $stmt->execute([
        ":name" => $name,
        ":description" => $description,
        ":price" => $price,
        ":quantity" => $Quantity,
        ":rating" => $rating,
        ":category" => $category,
        ":image1" => $image1,
        ":image2" => $image2,
        ":image3" => $image3
    ]);
    echo "New record created successfully";

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <title>
     add product
 </title>
</head>
<body>
<?php
include 'header.inc.php';
?>
<h1>hello dear employee?</h1>
<form method="post" action="add.php" enctype="multipart/form-data">
    <fieldset>
        <legend>add new product</legend>
        <label for="name">product name:</label>
        <input type="text" id="name" name="name" required>
        <br><br>
        <label for="description">product description:</label>
        <textarea id="description" name="description" required></textarea>
        <br><br>
        <label for="price">product price:</label>
        <input type="number" id="price" name="price" step="0.01" required>
        <br><br>
        <label for="category">product category:</label>
        <select id="category" name="category" required>
            <option value="olive oil">Olive Oil</option>
            <option value="traditional clothing">Traditional Clothing</option>
            <option value="decorative plates">Decorative Plates</option>
            <option value="souvenirs carved from olive wood">Souvenirs Carved from Olive Wood</option>
        </select>
        <br><br>

        <label for="Quantity">Quantity</label>
        <input type="number" id="quantity" name="quantity" required>
        <br><br>

        <label for="rate">Rating</label>
        <input type="number" id="rating" name="rating" step="0.1" min="1" max="5" required>
        <br><br>
        <label for="image1">product image1:</label>
        <input type="file" id="image1" name="image1" accept="image/jpeg" required>
        <br><br>
        <label for="image2">product image2:</label>
        <input type="file" id="image2" name="image2" accept="image/jpeg" required>
        <br><br>
        <label for="image3">product image3:</label>
        <input type="file" id="image3" name="image3" accept="image/jpeg" required>
        <br><br>
        <input type="submit" value="Add Product">
        <input type="reset" value="Reset">
    </fieldset>
</form>
<?php
include 'footer.inc.php';
?>
</body>

</html>