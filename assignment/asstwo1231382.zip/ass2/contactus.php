<!DOCTYPE html>
<html lang="en">
<head>
    <title>Contact US</title>
</head>
<body>
<a href="index.html">go back</a>

<header>
    <h1>PalStar</h1>
    <img src="images/logo.jpeg" alt="logo" width="80" height="80">

    <nav>
        <a href="index.html">Home</a>
        <a href="prod1.html">Olive Oil</a>
        <a href="prod2.html">Embroidered Dress</a>
        <a href="ContactUS.html">Contact Us</a>
        <a href="register.html">Register</a>
    </nav>
</header>
<h1>Contact Us</h1>
<h2>
    Contact information:-
</h2>
<address>
    PalStar Store<br>
    Nablus, Palestine<br>
    Phone: +970568270179<br>
    Email: palstar.store@gmail.com
</address>

<h2>Send Us a Message</h2>

<form method="post" action="http://comp334.studentswebprojects.ritaj.ps/util/process.php">

    <label for="name"> Name:</label>
    <input type="text" id="name" name="name" placeholder="Enter your name" required><br><br>

    <label for="email"> Email:</label>
    <input type="email" id="email" name="email" placeholder="yourmail@email.com" required><br><br>

    <label for="city">City:</label>
    <input type="text" id="city" name="city" placeholder="Your city" required><br><br>

    <label for="subject">Subject:</label>
    <input type="text" id="subject" name="subject" placeholder="subject " required><br><br>

    <label for="message">Message:</label>
    <textarea id="message" name="message" placeholder="Write your message............" required></textarea><br><br>

    <input type="submit" value="Send">
    <input type="reset" value="Reset">

</form>


<footer>
    <p>Last updated: April 2026</p>

    <address>
        PalStar Store<br>
        Nablus, Palestine<br>
        Phone: +970568270179<br>
        Email: palstar.store@gmail.com
    </address>

    <p><a href="ContactUS.html">Contact Us</a></p>
</footer>

</body>
</html>