<?php
session_start();
$pdo = require_once "dbconfig.inc.php";

if(($_SESSION['loggedIn'] == false) || ($_SESSION['role'] == 'employee')) {
    header("Location: products.php");
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'GET') {
    $id = $_GET['id'];
    $customerID = $_SESSION['ID'];

    $stmt = $pdo->prepare("SELECT * FROM products WHERE product_id = :id");
    $stmt->execute([":id" => $id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$result) {
        header("Location: products.php");
        exit();
    } else {
        $productId = $result['product_id'];
        $productName = $result['product_name'];
        $category = $result['category'];
        $description = $result['description'];
        $price = $result['price'];
        $quantity = $result['quantity'];
        $rating = $result['rating'];
        $photo1 = $result['photo1'];
        $photo2 = $result['photo2'];
        $photo3 = $result['photo3'];
        $defaultPhoto = $result['default_photo'];
    }
    $youcandoit = true;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['product_id'];
    $quantity_to_add = $_POST['quantity'];

    $stmt = $pdo->prepare("SELECT * FROM products WHERE product_id = :id");
    $stmt->execute([":id" => $id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if($result && $quantity_to_add <= $result['quantity']) {
        $defaultPhotoField = $result['default_photo'];
        $photoFilename = $result[$defaultPhotoField];

        if(!isset($_SESSION['basket'])) {
            $_SESSION['basket'] = [];
        }

        if(isset($_SESSION['basket'][$id])) {
            $_SESSION['basket'][$id]['quantity'] += $quantity_to_add;
        } else {
            $_SESSION['basket'][$id] = [
                'product_id' => $id,
                'product_name' => $result['product_name'],
                'unit_price' => $result['price'],
                'quantity' => $quantity_to_add,
                'photo' => $photoFilename
            ];
        }

        header("Location: basket.php");
        exit();
    } else {
        $error = "Not enough stock available.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>add to the basket</title>
</head>
<body>

<?php include("header.inc.php"); ?>

<?php if($youcandoit){ ?>

    <main>
        <h2>Add to Basket</h2>

        <?php if(isset($error)): ?>
            <p><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="post" action="add_to_basket.php">
            <fieldset>
                <legend>Product Details</legend>

                <input type="hidden" name="product_id" value="<?php echo $productId; ?>">

                <table border="1">
                    <tr>
                        <td>Product Name</td>
                        <td><?php echo $productName; ?></td>
                    </tr>
                    <tr>
                        <td>Price</td>
                        <td>$<?php echo $price; ?></td>
                    </tr>
                    <tr>
                        <td>Available Stock</td>
                        <td><?php echo $quantity; ?></td>
                    </tr>
                    <tr>
                        <td>Category</td>
                        <td><?php echo $category; ?></td>
                    </tr>
                    <tr>
                        <td>Quantity to Buy</td>
                        <td>
                            <input type="number" name="quantity" value="1" min="1" max="<?php echo $quantity; ?>" required>
                            </td>
                    </tr>
                </table>

                <br>
                <input type="submit" value="Add to Basket">
                <a href="products.php">Cancel</a>
            </fieldset>
        </form>
    </main>

<?php } ?>

<?php include("footer.inc.php"); ?>

</body>
</html>