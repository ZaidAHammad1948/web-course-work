<?php
session_start();
$pdo = require('dbconfig.inc.php');
require_once 'Product.class.php';


$id = $_SESSION['ID'] ?? null;
$email = $_SESSION['email'] ?? null;
$role = $_SESSION['role'] ?? 'guest';

$name_filter = '';
$max_price = '';
$category_filter = '';
$sort_col = 'product_id';
$sort_dir = 'ASC';
$current_page = 1;
$per_page = 5;

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['filter'])) {
    $search_state = [
            'name' => trim($_POST['name'] ?? ''),
            'max_price' => trim($_POST['max_price'] ?? ''),
            'category' => trim($_POST['category'] ?? ''),
            'sort_col' => 'product_id',
            'sort_dir' => 'ASC',
            'current_page' => 1,
            'per_page' => $_POST['per_page'] ?? 5
    ];
    $_SESSION['product_search_state'] = json_encode($search_state);
    header("Location: products.php");
    exit();
}
elseif(isset($_GET['sort_col']) || isset($_GET['page'])) {
    $saved = $_SESSION['product_search_state'] ?? '{}';
    $search_state = json_decode($saved, true);

    if(isset($_GET['sort_col'])) {
        $search_state['sort_col'] = $_GET['sort_col'];
        $current_dir = $search_state['sort_dir'] ?? 'ASC';
        $search_state['sort_dir'] = ($current_dir == 'ASC') ? 'DESC' : 'ASC';
    }

    if(isset($_GET['page'])) {
        $search_state['current_page'] = (int)$_GET['page'];
    }

    $_SESSION['product_search_state'] = json_encode($search_state);
    header("Location: products.php");
    exit();
}
elseif(isset($_GET['reset'])) {
    unset($_SESSION['product_search_state']);
    header("Location: products.php");
    exit();
}

if(isset($_SESSION['product_search_state'])) {
    $search_state = json_decode($_SESSION['product_search_state'], true);
    $name_filter = $search_state['name'] ?? '';
    $max_price = $search_state['max_price'] ?? '';
    $category_filter = $search_state['category'] ?? '';
    $sort_col = $search_state['sort_col'] ?? 'product_id';
    $sort_dir = $search_state['sort_dir'] ?? 'ASC';
    $current_page = $search_state['current_page'] ?? 1;
    $per_page = $search_state['per_page'] ?? 5;
}

$where_conditions = [];
$params = [];

if(!empty($name_filter)) {
    $where_conditions[] = "product_name LIKE :name";
    $params[':name'] = "%$name_filter%";
}

if(!empty($max_price)) {
    $where_conditions[] = "price <= :max_price";
    $params[':max_price'] = $max_price;
}

if(!empty($category_filter)) {
    $where_conditions[] = "category = :category";
    $params[':category'] = $category_filter;
}

$where_sql = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";

$count_sql = "SELECT COUNT(*) as total FROM products $where_sql";
$stmt = $pdo->prepare($count_sql);
$stmt->execute($params);
$total_records = $stmt->fetch()['total'];

$per_page_value = $per_page;
if($per_page == 'all') {
    $per_page = $total_records;
    $per_page_value = 'all';
} else {
    $per_page = (int)$per_page;
}

$total_pages = ($per_page > 0) ? ceil($total_records / $per_page) : 1;
$offset = ($current_page - 1) * $per_page;

$sql = "SELECT product_id, product_name, category, description, price, quantity, rating, photo1, photo2, photo3, default_photo 
        FROM products 
        $where_sql 
        ORDER BY $sort_col $sort_dir 
        LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($sql);
$stmt->bindValue(':limit', (int)$per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
$stmt->execute();

$cat_stmt = $pdo->query("SELECT DISTINCT category FROM products ORDER BY category");
$categories = $cat_stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Products - PalStar</title>
</head>
<body>

<?php include("header.inc.php"); ?>

<main>
    <h1>Our Products</h1>

    <?php if($role == 'employee'): ?>
        <p><a href="add.php">+ Add New Product</a></p>
    <?php endif; ?>

    <form method="post" action="products.php">
        <fieldset>
            <legend> Product Search</legend>

            <label for="name">Product Name:</label>
            <input type="text" id="name" name="name" placeholder="Product Name" value="<?php echo $name_filter; ?>">
            <br><br>

            <label for="max_price">Maximum Price ($):</label>
            <input type="number" id="max_price" name="max_price" placeholder="Max Price" step="0.01" value="<?php echo $max_price; ?>">
            <br><br>

            <label for="category">Category:</label>
            <select id="category" name="category">
                <option value="">Select Category</option>
                <?php foreach($categories as $cat): ?>
                    <option value="<?php echo $cat['category']; ?>" <?php echo ($category_filter == $cat['category']) ? 'selected' : ''; ?>>
                        <?php echo $cat['category']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <br><br>

            <label for="per_page">Items Per Page:</label>
            <select id="per_page" name="per_page">
                <option value="5" <?php echo ($per_page_value == 5) ? 'selected' : ''; ?>>5</option>
                <option value="10" <?php echo ($per_page_value == 10) ? 'selected' : ''; ?>>10</option>
                <option value="15" <?php echo ($per_page_value == 15) ? 'selected' : ''; ?>>15</option>
                <option value="20" <?php echo ($per_page_value == 20) ? 'selected' : ''; ?>>20</option>
                <option value="all" <?php echo ($per_page_value == 'all') ? 'selected' : ''; ?>>All</option>
            </select>
            <br><br>

            <input type="submit" name="filter" value="Filter">
            <a href="products.php?reset=1">Reset / Show All</a>
        </fieldset>
    </form>
    <br>

    <table border="1">
        <thead>
        <tr>
            <th>Image</th>
            <th><a href="?sort_col=product_id">Product ID</a></th>
            <th>Product Name</th>
            <th><a href="?sort_col=category">Category</a></th>
            <th><a href="?sort_col=price">Price</a></th>
            <th>Quantity</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php if($stmt->rowCount() > 0): ?>
            <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                <?php
                $product = new Product(
                        $row['product_id'],
                        $row['product_name'],
                        $row['category'],
                        $row['description'],
                        $row['price'],
                        $row['quantity'],
                        $row['rating'],
                        $row['photo1'],
                        $row['photo2'],
                        $row['photo3'],
                        $row['default_photo']
                );
                echo $product->displayInTable($role);
                ?>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="7">No products found</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>

    <?php if($total_pages > 1): ?>
        <p>Page <?php echo $current_page; ?> of <?php echo $total_pages; ?></p>
        <p>
            <?php if($current_page > 1): ?>
                <a href="?page=<?php echo $current_page - 1; ?>">Previous</a>
            <?php endif; ?>
            <?php if($current_page < $total_pages): ?>
                <a href="?page=<?php echo $current_page + 1; ?>">Next</a>
            <?php endif; ?>
        </p>
    <?php endif; ?>

</main>

<?php include("footer.inc.php"); ?>

</body>
</html>