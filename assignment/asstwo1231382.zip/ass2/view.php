<?php
session_start();
$role = $_SESSION['role'] ?? 'guest';
$pdo = require('dbconfig.inc.php');
require_once 'Product.class.php';

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $product_id = $_GET['id'] ?? 0;

    if($product_id <= 0) {
        include 'header.inc.php';
        echo "<main><h2>Error</h2><p>Invalid product ID.</p><a href='products.php'>Back to Products</a></main>";
        include 'footer.inc.php';
        exit();
    }

    $stmt = $pdo->prepare("SELECT * FROM products WHERE product_id = :id");
    $stmt->execute([":id" => $product_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$result) {
        include 'header.inc.php';
        echo "<main><h2>Error</h2><p>Product not found.</p><a href='products.php'>Back to Products</a></main>";
        include 'footer.inc.php';
        exit();
    } else {
        $productId = $result['product_id'];
        $productName = $result['product_name'];
        $category = $result['category'];
        $description = $result['description'];
        $price = $result['price'];
        $quantity = $result['quantity'];
        $rating = $result['rating'];
        $photo1 = $result['photo1'];
        $photo2 = $result['photo2'];
        $photo3 = $result['photo3'];
        $defaultPhoto = $result['default_photo'];

        $product = new Product($productId, $productName, $category, $description, $price, $quantity, $rating, $photo1, $photo2, $photo3, $defaultPhoto);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Product - PalStar</title>
</head>
<body>
<?php
include 'header.inc.php';
echo $product->displayProductPage($role);
include 'footer.inc.php';
?>
</body>
</html>