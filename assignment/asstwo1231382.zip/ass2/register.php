<?php
$pdo=require "dbconfig.inc.php";
function generateRandomNumber($length = 10) {
    $characters = '0123456789';
    $charactersLength = strlen($characters);
    $randomString = '';

    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $formData = [
        "fname" => $_POST["fname"],
        "lname" => $_POST["lname"],
        "email" => $_POST["email"],
        "phone" => $_POST["phone"],
        "DOB" => $_POST["DOB"] ,
        "flat" => $_POST["flat"],
        "streetAddress" => $_POST["street"],
        "city" => $_POST["city"],
        "country" => $_POST["country"],
        "postcode" => $_POST["postal"],
        "role" => $_POST["role"] ,
        "password" => $_POST["password"],
        "password2" => $_POST["rePassword"]
    ];

    if($formData["password"] != $formData["password2"]){
        echo "password not match";
        exit;
    }

    $req = ['fname','lname','email','phone','DOB','flat','streetAddress','city','country','postcode'];

    $countErr = 0;

    foreach($req as $value){
        if(empty($formData[$value])){
            echo $value . " is required <br>";
            $countErr++;
        }
    }

    if($countErr == 0){

        $sql = "INSERT INTO users 
                    (user_id, first_name, last_name, email, mobile, birth_date, flat_no, street_address, city, country, postal_code, role, password)
                    VALUES 
                    (:id, :fname, :lname, :email, :phone, :DOB, :flat, :streetAddress, :city, :country, :postcode, :role, :password)";

        $stmt = $pdo->prepare($sql);
        $generatedId = generateRandomNumber();

        $stmt->execute([
            ":id"    => $generatedId,
            ":fname" => $formData["fname"],
            ":lname" => $formData["lname"],
            ":DOB" => $formData["DOB"],
            ":email" => $formData["email"],
            ":phone" => $formData["phone"],
            ":flat" => $formData["flat"],
            ":streetAddress" => $formData["streetAddress"],
            ":city" => $formData["city"],
            ":country" => $formData["country"],
            ":postcode" => $formData["postcode"],
            ":role" => $formData["role"],
            ":password" => password_hash($formData["password"], PASSWORD_DEFAULT)
        ]);

        echo "User inserted successfully!";
        if ($stmt) {
            $displayUserId = str_pad($generatedId, 10, '0', STR_PAD_LEFT);


            echo "<h2>Registration Successful!</h2>";
            echo "<p>Your 10-digit User ID is: <strong>$displayUserId</strong></p>";
            echo "<p><a href='login.php'>Click here to login</a></p>";
            exit;
        }
    }else {
        echo "failed >_-";
    }

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>
        register
    </title>
</head>
<body>
<?php
include "header.inc.php";
?>
<h1>
    palstar store Registration:
</h1>
<form method="post">

    <fieldset>
        <legend>Register:-
            <br>Personal Information</legend>

        <label for="fname">First Name:</label>
        <input type="text" id="fname" name="fname" placeholder="Enter first name" required><br><br>

        <label for="lname">Last Name:</label>
        <input type="text" id="lname" name="lname" placeholder="Enter last name" required><br><br>

        <label for="DOB">Date of Birth</label>
        <input type="Date" id="DOB" name="DOB" required><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" placeholder="example@email.com" required><br><br>

        <label for="phone">Phone:</label>
        <input type="text" id="phone" name="phone" placeholder="your Phone Number" required><br><br>

        <label for="role">Role:</label>
        <select id="role" name="role" required>
            <option value="">Select Role</option>
            <option value="customer">customer</option>
            <option value="employee">employee</option>
        </select><br><br>
    </fieldset>
    <br>

    <fieldset>
        <legend>your Address:</legend>

        <label for="street">Street Address:</label><br>
        <textarea id="street" name="street" placeholder="Enter your street address" required></textarea><br><br>

        <label for="city">City:</label>
        <input type="text" id="city" name="city" placeholder="Your city" required><br><br>

        <label for ="flat">Flat Number:</label>
        <input type="text" id="flat" name="flat" placeholder="Your flat number" required><br><br>

        <label for="postal">Postal Code:</label>
        <input type="text" id="postal" name="postal" placeholder="Postal code" required><br><br>

        <label for="country">Country:</label>
        <input type="text" id="country" name="country" placeholder="Your country" required><br><br>

    </fieldset>
    <br>
    <fieldset>
        <legend>Your Password:</legend>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" placeholder="Enter password" required><br><br>

        <label for="re-password">Confirm Password:</label>
        <input type="password" id="re-password" name="rePassword" placeholder="re-password" required><br><br>

    </fieldset>

    <input type="submit" value="Register">
    <input type="reset" value="Reset">

</form>
<h2>
    do you have an account?
    <a href="login.php">
        click here
    </a>
</h2>
<?php
include "footer.inc.php";
?>

</body>
</html>




