<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'web1231382_dbuser');
define('DB_PASS', 'web1231382_dbuserr');
define('DB_NAME', 'web1231382_souvenirStore');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS
    );

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $pdo;

} catch (Exception $e) {
    die("Connection failed: " . $e->getMessage());
}
?>