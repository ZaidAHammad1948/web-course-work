<?php
session_start();

$_SESSION['logged_in'] = false;
$_SESSION['user_id'] = null;
$_SESSION['first_name'] = null;
$_SESSION['last_name'] = null;
$_SESSION['email'] = null;
$_SESSION['role'] = null;
session_destroy();
header("Location: login.php");
exit();
?>