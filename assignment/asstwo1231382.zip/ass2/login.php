<?php
session_start();
$pdo = require 'dbconfig.inc.php';

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = '$email'";
    $prepare = $pdo->query($sql);

    $row = $prepare->fetch(PDO::FETCH_ASSOC);

    if (!$row || !password_verify($password, $row['password'])) {
        die("Invalid Email or Password");
    } else {
        $_SESSION['loggedIn'] = true;
        $_SESSION['ID'] = $row['user_id'];
        $_SESSION['email'] = $row['email'];
        $_SESSION['role'] = $row['role'];
        $_SESSION['Name'] = $row['first_name'] . " " . $row['last_name'];

        header("Location: products.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>
        login
    </title>
</head>
<body>

<?php
include 'header.inc.php';
?>

<h1>
    Login
</h1>

<form method="post" action="login.php">
    <fieldset>
        <legend>
            your info
        </legend>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" placeholder="example@email"><br><br>

        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="your password"><br><br>

        <input type="submit" value="login" name="login"><br><br>
        <input type="reset" value="remove">
    </fieldset>
</form>

<div>
    <h2>
        dont have account?
        <a href="register.php">
            click here
        </a>
    </h2>
    <h3>
    dubug (guest)
    <br>
    <a href="products.php">click here<a>
    </h3>
</div>

<?php
include 'footer.inc.php';
?>

</body>
</html>
