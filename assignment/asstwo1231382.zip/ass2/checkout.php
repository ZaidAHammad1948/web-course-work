<?php
session_start();
$pdo = require_once "dbconfig.inc.php";

$role = $_SESSION['role'] ?? 'guest';

if($_SESSION['loggedIn'] == false or $role == 'employee' or $role == 'guest'){
    header("Location: login.php");
    exit();
}

$basket = isset($_SESSION['basket']) ? $_SESSION['basket'] : [];

if(empty($basket)){
    header("Location: products.php");
    exit();
}

$total = 0;
foreach($basket as $it){
    $total = $total + ($it['unit_price'] * $it['quantity']);
}

$err = "";
$done = false;
$oid = '';

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $cname = trim($_POST['cname'] ?? '');
    $cnum = trim($_POST['cnum'] ?? '');
    $emon = $_POST['emon'] ?? '';
    $eyear = $_POST['eyear'] ?? '';
    $cvv = trim($_POST['cvv'] ?? '');

    if(empty($cname)){
        $err = "Cardholder name is required.";
    } elseif(empty($cnum) || strlen($cnum) != 16){
        $err = "Card number must be 16 digits.";
    } elseif(empty($emon)){
        $err = "Expiry month is required.";
    } elseif(empty($eyear)){
        $err = "Expiry year is required.";
    } elseif(empty($cvv) || strlen($cvv) != 3){
        $err = "CVV must be 3 digits.";
    } else {
        $oid = '';
        for($i = 0; $i < 10; $i++){
            $oid = $oid . rand(0, 9);
        }

        $uid = $_SESSION['ID'];
        $odate = date('Y-m-d H:i:s');

        $sql = "INSERT INTO orders (order_id, user_id, order_date, total_amount) 
                VALUES ('$oid', '$uid', '$odate', '$total')";
        $pdo->query($sql);

        foreach($basket as $pid => $it){
            $qty = $it['quantity'];
            $prc = $it['unit_price'];

            $sql2 = "INSERT INTO order_items (order_id, product_id, quantity, price) 
                     VALUES ('$oid', '$pid', '$qty', '$prc')";
            $pdo->query($sql2);

            $upd = "UPDATE products SET quantity = quantity - $qty WHERE product_id = $pid";
            $pdo->query($upd);
        }

        unset($_SESSION['basket']);
        $done = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>checkout</title>
</head>
<body>

<?php include("header.inc.php"); ?>

<main>
    <?php if($done): ?>
        <h2>Order Confirmation</h2>
        <p>Thank you for your order!</p>
        <p>Your 10-digit Order ID is: <strong><?php echo $oid; ?></strong></p>
        <p>Order Total: <strong>$<?php echo number_format($total, 2); ?></strong></p>
        <p><a href="products.php">Continue Shopping</a></p>
    <?php else: ?>

        <h1>Checkout</h1>

        <h2>Order Summary</h2>
        <table border="1">
            <thead>
            <tr>
                <th>Image</th>
                <th>Product Name</th>
                <th>Unit Price</th>
                <th>Quantity</th>
                <th>Total</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($basket as $it):
                $ln = $it['unit_price'] * $it['quantity'];
                ?>
                <tr>
                    <td><img src="images/<?php echo $it['photo']; ?>" width="50"></td>
                    <td><?php echo $it['product_name']; ?></td>
                    <td>$<?php echo $it['unit_price']; ?></td>
                    <td><?php echo $it['quantity']; ?></td>
                    <td>$<?php echo $ln; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
            <tr>
                <td colspan="4"><strong>Grand Total:</strong></td>
                <td><strong>$<?php echo number_format($total, 2); ?></strong></td>
            </tr>
            </tfoot>
        </table>

        <br>

        <form method="post" action="checkout.php">
            <fieldset>
                <legend>Payment Information</legend>

                <?php if(!empty($err)): ?>
                    <p><?php echo $err; ?></p>
                <?php endif; ?>

                <label for="cname">Cardholder Name:</label>
                <input type="text" id="cname" name="cname" required>
                <br><br>

                <label for="cnum">Card Number (16 digits):</label>
                <input type="text" id="cnum" name="cnum" maxlength="16" required>
                <br><br>

                <label for="emon">Expiry Month:</label>
                <select id="emon" name="emon" required>
                    <option value="">Select Month</option>
                    <?php for($m = 1; $m <= 12; $m++): ?>
                        <option value="<?php echo $m; ?>"><?php echo $m; ?></option>
                    <?php endfor; ?>
                </select>
                <br><br>

                <label for="eyear">Expiry Year:</label>
                <select id="eyear" name="eyear" required>
                    <option value="">Select Year</option>
                    <?php $cy = date('Y'); ?>
                    <?php for($y = $cy; $y <= $cy + 10; $y++): ?>
                        <option value="<?php echo $y; ?>"><?php echo $y; ?></option>
                    <?php endfor; ?>
                </select>
                <br><br>

                <label for="cvv">CVV (3 digits):</label>
                <input type="text" id="cvv" name="cvv" maxlength="3" required>
                <br><br>

                <input type="submit" value="Place Order">
                <a href="basket.php">Back to Basket</a>
            </fieldset>
        </form>

    <?php endif; ?>
</main>

<?php include("footer.inc.php"); ?>

</body>
</html>